class SimpleTuringMachine:
    def __init__(self, name, transitions, start_state, accept_state, reject_state):
        self.name = name
        self.transitions = transitions
        self.start_state = start_state
        self.accept_state = accept_state
        self.reject_state = reject_state

    def simulate(self, input_string, max_steps=100, verbose=True):
        tape = list(input_string) + ['_']
        head = 0
        state = self.start_state
        steps = 0

        if verbose:
            print(f"\n--- Simulating on Input: '{input_string}' ---\n")

        while steps < max_steps:
            current_symbol = tape[head] if 0 <= head < len(tape) else '_'
            key = (state, current_symbol)

            if verbose:
                tape_display = ''.join(tape)
                head_display = ' ' * head + '^'
                print(f"Step {steps}:")
                print(f"Tape: {tape_display}")
                print(f"      {head_display}")
                print(f"State: {state}, Read: '{current_symbol}'")

            if key not in self.transitions:
                if verbose:
                    print("No valid transition found. Halting and rejecting.\n")
                return 'REJECT'

            new_state, write_symbol, direction = self.transitions[key]
            if verbose:
                print(f"Action: Write '{write_symbol}', Move {direction}, New State: {new_state}\n")

            tape[head] = write_symbol

            if direction == 'R':
                head += 1
                if head >= len(tape):
                    tape.append('_')
            elif direction == 'L':
                head -= 1
                if head < 0:
                    tape = ['_'] + tape
                    head = 0

            state = new_state
            steps += 1

            if state == self.accept_state:
                if verbose:
                    print("✅ TM accepted the input.\n")
                return 'ACCEPT'
            elif state == self.reject_state:
                if verbose:
                    print("❌ TM rejected the input.\n")
                return 'REJECT'

        if verbose:
            print("⚠️ Maximum steps reached. Machine did not halt.\n")
        return 'LOOP'