import argparse
from tm_machine import SimpleTuringMachine
from transition_tables import get_palindrome_tm
from tests import palindrome_inputs
from gui import run_gui

def cli_mode():
    tm = get_palindrome_tm()

    while True:
        input_str = input("Enter input string (or 'exit'): ")
        if input_str.lower() == 'exit':
            break
        tm.simulate(input_str)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--gui', action='store_true', help='Run GUI interface')
    args = parser.parse_args()

    if args.gui:
        run_gui()
    else:
        cli_mode()
