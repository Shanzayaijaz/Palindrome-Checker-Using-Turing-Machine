import tkinter as tk
from tkinter import ttk
from tm_machine import SimpleTuringMachine
from transition_tables import get_palindrome_tm

def run_gui():
    def run_sim():
        # Clear previous output
        tape_display.delete(1.0, tk.END)
        state_display.config(text="Current State: q0")
        
        input_str = entry.get()
        if not input_str:
            output_var.set("Please enter a binary string")
            return
            
        # Run simulation and capture output
        result = machine.simulate(input_str, verbose=False)
        output_var.set(f"Result: {result}")
        
        # Display the tape
        tape = list(input_str) + ['_']
        tape_display.insert(tk.END, "Initial Tape:\n")
        tape_display.insert(tk.END, "".join(tape) + "\n")
        tape_display.insert(tk.END, "^" + " " * (len(tape) - 1) + "\n\n")
        
        # Simulate step by step
        head = 0
        state = 'q0'
        while True:
            current_symbol = tape[head] if 0 <= head < len(tape) else '_'
            key = (state, current_symbol)
            
            if key not in machine.transitions:
                break
                
            new_state, write_symbol, direction = machine.transitions[key]
            tape[head] = write_symbol
            
            # Update display
            tape_display.insert(tk.END, f"State: {state}, Read: '{current_symbol}'\n")
            tape_display.insert(tk.END, "".join(tape) + "\n")
            tape_display.insert(tk.END, " " * head + "^" + "\n\n")
            
            # Update state
            state = new_state
            state_display.config(text=f"Current State: {state}")
            
            # Move head
            if direction == 'R':
                head += 1
                if head >= len(tape):
                    tape.append('_')
            elif direction == 'L':
                head -= 1
                if head < 0:
                    tape = ['_'] + tape
                    head = 0
            
            if state in [machine.accept_state, machine.reject_state]:
                break

    def clear_all():
        entry.delete(0, tk.END)
        tape_display.delete(1.0, tk.END)
        output_var.set("")
        state_display.config(text="Current State: q0")

    machine = get_palindrome_tm()

    root = tk.Tk()
    root.title("Turing Machine Simulator")
    root.geometry("500x500")

    # Main frame
    main_frame = ttk.Frame(root, padding="10")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # Title
    ttk.Label(main_frame, text="Palindrome Checker", font=("Arial", 12, "bold")).pack(pady=5)

    # Input section
    input_frame = ttk.Frame(main_frame)
    input_frame.pack(fill=tk.X, pady=5)
    
    ttk.Label(input_frame, text="Input:").pack(side=tk.LEFT)
    entry = ttk.Entry(input_frame)
    entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
    
    # Buttons
    button_frame = ttk.Frame(main_frame)
    button_frame.pack(fill=tk.X, pady=5)
    
    ttk.Button(button_frame, text="Run", command=run_sim).pack(side=tk.LEFT, padx=5)
    ttk.Button(button_frame, text="Clear", command=clear_all).pack(side=tk.LEFT, padx=5)

    # State display
    state_display = ttk.Label(main_frame, text="Current State: q0")
    state_display.pack(pady=5)

    # Tape display
    tape_frame = ttk.LabelFrame(main_frame, text="Tape")
    tape_frame.pack(fill=tk.BOTH, expand=True, pady=5)
    
    tape_display = tk.Text(tape_frame, height=10, width=40, font=("Courier New", 10))
    tape_display.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
    
    # Result display
    output_var = tk.StringVar()
    ttk.Label(main_frame, textvariable=output_var).pack(pady=5)

    root.mainloop()