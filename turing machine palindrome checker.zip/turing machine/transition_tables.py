from tm_machine import SimpleTuringMachine

def get_palindrome_tm():
    transitions = {
        # State q0: Check leftmost symbol, mark it, and move right.
        ('q0', '0'): ('q1', 'x', 'R'),  # Mark '0' as 'x' and move right
        ('q0', '1'): ('q2', 'x', 'R'),  # Mark '1' as 'x' and move right
        ('q0', 'x'): ('q0', 'x', 'R'),  # Skip over marked symbols
        ('q0', '_'): ('qa', '_', 'R'),  # Accept if we've reached the blank and everything matched

        # State q1: Moving right to find the end of the string
        ('q1', '0'): ('q1', '0', 'R'),  # Keep moving right over '0'
        ('q1', '1'): ('q1', '1', 'R'),  # Keep moving right over '1'
        ('q1', 'x'): ('q1', 'x', 'R'),  # Keep moving right over marked symbols
        ('q1', '_'): ('q3', '_', 'L'),  # Reached the end, move left

        # State q2: Moving right to find the end of the string
        ('q2', '0'): ('q2', '0', 'R'),  # Keep moving right over '0'
        ('q2', '1'): ('q2', '1', 'R'),  # Keep moving right over '1'
        ('q2', 'x'): ('q2', 'x', 'R'),  # Keep moving right over marked symbols
        ('q2', '_'): ('q5', '_', 'L'),  # Reached the end, move left

        # State q3: Check for the '0' symbol on the rightmost side and move left
        ('q3', '0'): ('q4', 'x', 'L'),  # Mark '0' as 'x' and move left
        ('q3', '1'): ('qr', '1', 'R'),  # Reject if there's a mismatch (1 on the right, should be 0)
        ('q3', 'x'): ('q3', 'x', 'L'),  # Keep moving left over marked symbols
        ('q3', '_'): ('qa', '_', 'R'),  # Accept if we've reached the blank and everything matched

        # State q4: Move left to find the next unmarked symbol
        ('q4', '0'): ('q4', '0', 'L'),
        ('q4', '1'): ('q4', '1', 'L'),
        ('q4', 'x'): ('q0', 'x', 'R'),  # Return to the start state to continue checking

        # State q5: Check for the '1' symbol on the rightmost side and move left
        ('q5', '0'): ('qr', '0', 'R'),  # Reject if there's a mismatch (0 on the right, should be 1)
        ('q5', '1'): ('q4', 'x', 'L'),  # Mark '1' as 'x' and move left
        ('q5', 'x'): ('q5', 'x', 'L'),  # Keep moving left over marked symbols
        ('q5', '_'): ('qa', '_', 'R'),  # Accept if we've reached the blank and everything matched
    }

    return SimpleTuringMachine(
        name="Binary Palindrome TM",
        transitions=transitions,
        start_state='q0',
        accept_state='qa',
        reject_state='qr'
    )
